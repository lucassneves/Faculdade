#include <stdio.h> // biblioteca padrão
#include <stdlib.h> // nós vamos usar alocação dinamica
#include "cilindro.h" // biblioteca com as funções criadas

struct cilindro {
	float altura;
	float raio;
};

//cria um novo cilindro
cilindro * cria_cilindro(void){
	cilindro * c;
	c = malloc (sizeof (cilindro));
	if (c == NULL){
		return NULL;
	}
	return c;
}

//libera um cilindro
void libera_cilindro (cilindro *c){
	free(c);
}

//atribui os valores de "altura" e "raio" para um cilindro
void atribui_cilindro (cilindro *c,float altura, float raio) {
	c->altura = altura;
	c->raio = raio;
}

// calcula o volume de um cilindro com os valores de um cilindro
float volume_cilindro(cilindro *c){
	return (altura_acessa(c) * area_base(c)); 
}

// calcula a area da base de um cilindro com os valores de um cilindro
float area_base(cilindro *c){
	return (raio_acessa(c) * raio_acessa(c) * PI);
}

//// calcula a circunferencia da base de um cilindro com os valores de um cilindro
float circunferencia_da_base(cilindro *c){
	return (2 *raio_acessa(c)*PI);
}

// calcula  a area lateral de um cilindro com os valores de um cilindro
float area_lateral (cilindro *c){
	return (altura_acessa(c) * circunferencia_da_base(c));
}

// calcula a area total(superficial) de um cilindro com os valores de um cilindro
float area_total (cilindro *c) {
 	return (area_lateral(c) + 2 * area_base(c));
 }

//acessa o valor "raio" para um cilindro
float raio_acessa(cilindro *c){
 	return c->raio;
}

//acessa o valor "altura" para um cilindro0
float altura_acessa (cilindro*c){
 	return c->altura;
}

//scanear os valores recebidos por um usuarios
void scan_cilindro(cilindro *c){
 	float altura, raio;
 	scanf ("%f %f",&raio,&altura);
 	atribui_cilindro(c,altura,raio);
}
