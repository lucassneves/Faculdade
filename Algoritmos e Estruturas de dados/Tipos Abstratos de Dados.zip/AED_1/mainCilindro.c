#include <stdio.h>
#include <stdio.h>
#include "cilindro.h"

int main () {
	cilindro *c ;
	c = cria_cilindro();
    /* Parte pronta para escanear valores do proprio usuários
   
    */ 
    scan_cilindro(c);

    printf("O volume do cilindro é %.2f\n",volume_cilindro(c));
    printf ("A area da superficie do cilindro é %.2f\n",area_total (c));

    libera_cilindro(c);
	return 0; 
}