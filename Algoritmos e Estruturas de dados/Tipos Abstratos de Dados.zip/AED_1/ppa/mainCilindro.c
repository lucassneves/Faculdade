#include <stdio.h>
#include <stdlib.h>
#include "cilindro.h"

int main () {
	cilindro *c;
	c = cria_cilindro();
    /* Parte pronta para escanear valores do proprio usuários
   
    */
    printf("Insira o Raio e a Altura, para obter o Volume e Área!\n");
    scan_cilindro(c);

    printf("Raio: %.2f\n",raio_acessa(c));
    printf("Altura: %.2f\n",altura_acessa(c));
    printf("O volume do cilindro é: %.2f\n",volume_cilindro(c));
    printf ("A area da superficie do cilindro é: %.2f\n",area_total (c));

    libera_cilindro(c);
    return 0; 
}