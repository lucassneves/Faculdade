#include <stdio.h> // biblioteca padrão
#include <stdlib.h> // nós vamos usar alocação dinamica
// #include "esfera.h" // biblioteca com as funções criadas

struct esfera {
	float raio;
};

//cria um novo esfera
esfera * cria_esfera(void){
	esfera * c;
	c = malloc (sizeof (esfera)); 
	if (c == NULL){
		return NULL;
	}
	return c;
}

//libera um esfera
void libera_esfera (esfera *c){
	free(c);
}

//atribui os valores de "altura" e "raio" para um esfera
void atribui_esfera (esfera * c, float raio) {
	c->raio = raio;
}

// calcula o volume de um esfera com os valores de um esfera
float volume_esfera(esfera *c){
    return (c->raio*c->raio*c->raio * (3/4) * PI); 
}

// calcula  a area lateral de um esfera com os valores de um esfera
float area_lateral (esfera *c){
	return (altura_acessa(c) * circunferencia_da_base(c));
}

// calcula a area total(superficial) de um esfera com os valores de um esfera
float area_total (esfera *c) {
    // derivada do volume
 	return (c->raio * c->raio * 4 * PI);
 }

//acessa o valor "raio" para um esfera
float raio_acessa(esfera *c){
 	return c->raio;
}

//acessa o valor "altura" para um esfera0
float altura_acessa (esfera*c){
 	return c->altura;
}

//scanear os valores recebidos por um usuarios
void scan_esfera(esfera *c){
 	float altura, raio;
 	scanf ("%f %f",&raio,&altura);
 	atribui_esfera(c,altura,raio);
}
