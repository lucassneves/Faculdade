//Arquivo cilindro.h
#define PI 3.14159

typedef  struct cilindro cilindro;

//cria um novo cilindro
cilindro * cria_cilindro(void);

//libera um cilindro
void libera_cilindro (cilindro *c);

//atribui os valores de "altura" e "raio" para um cilindro
void atribui_cilindro (cilindro *c,float altura, float raio);

// calcula o volume de um cilindro com os valores de um cilindro
float volume_cilindro(cilindro *c);

// calcula a area da base de um cilindro com os valores de um cilindro
float area_base(cilindro *c);

//// calcula a circunferencia da base de um cilindro com os valores de um cilindro
float circunferencia_da_base(cilindro *c);

// calcula  a area lateral de um cilindro com os valores de um cilindro
float area_lateral (cilindro *c);

// calcula a area total de um cilindro com os valores de um cilindro
float area_total (cilindro *c);

//acessa o valor "raio" para um cilindro
float raio_acessa(cilindro *c);

//acessa o valor "altura" para um cilindro
float altura_acessa (cilindro*c);

//scanear os valores recebidos por um usuarios
void scan_cilindro(cilindro *c);
